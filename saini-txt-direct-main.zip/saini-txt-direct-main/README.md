![Typing SVG](https://readme-typing-svg.herokuapp.com/?lines=Welcome+To+Txt+Uploader+Bot+!)

Welcome to NON-DRM bot made by @nikhil.saini.khe (TELEGRAM & Instagram)

#command
```
/start start the bot
/stop stop the bot
/help to get help in using this bot
```
Direct Deploy via click these button 

## Deploy to Heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://www.github.com/nikhilsainiop/saini-txt-direct)

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/nikhilsainiop/saini-txt-direct)

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?name=saini-txt-direct&repository=nikhilsainiop%2Fsaini-txt-direct&branch=main&instance_type=free&instances_min=0)
